import discord
from discord.ext import commands
import asyncio
import yt_dlp as youtube_dl
import os

# Configuration
TOKEN = os.getenv('DISCORD_TOKEN', 'MTMyNTU5MjY5MTA1MTg1OTk5OA.GaqqFW.FPfHXifeFThoZukfOZQU_1Pjd9u6LF6uYhcr3c')
PREFIX = os.getenv('PREFIX', '!')

# Configuration de youtube_dl
ytdl_format_options = {
    'format': 'bestaudio/best',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'auto',
    'source_address': '0.0.0.0',
}

ffmpeg_options = {
    'options': '-vn'
}

ytdl = youtube_dl.YoutubeDL(ytdl_format_options)

class YTDLSource(discord.PCMVolumeTransformer):
    def __init__(self, source, *, data, volume=0.5):
        super().__init__(source, volume)
        self.data = data
        self.title = data.get('title')
        self.url = data.get('url')

    @classmethod
    async def from_url(cls, url, *, loop=None, stream=False):
        loop = loop or asyncio.get_event_loop()
        data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=not stream))

        if 'entries' in data:
            data = data['entries'][0]

        filename = data['url'] if stream else ytdl.prepare_filename(data)
        return cls(discord.FFmpegPCMAudio(filename, **ffmpeg_options), data=data)

# Initialisation du bot
intents = discord.Intents.default()
intents.message_content = True
intents.voice_states = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

# File d'attente de musique
music_queue = {}

@bot.event
async def on_ready():
    print(f'Bot connecté en tant que {bot.user.name} (ID: {bot.user.id})')
    print('------')
    await bot.change_presence(activity=discord.Game(name=f"{PREFIX}help"))

@bot.command(name='play', aliases=['p'], help='Joue une musique depuis YouTube')
async def play(ctx, *, url):
    """Joue une musique depuis YouTube"""
    
    # Vérifier si l'utilisateur est dans un salon vocal
    if not ctx.author.voice:
        await ctx.send("❌ Vous devez être dans un salon vocal pour utiliser cette commande.")
        return

    voice_channel = ctx.author.voice.channel
    
    # Se connecter au salon vocal si le bot n'y est pas déjà
    if ctx.voice_client is None:
        await voice_channel.connect()
    elif ctx.voice_client.channel != voice_channel:
        await ctx.voice_client.move_to(voice_channel)

    async with ctx.typing():
        try:
            player = await YTDLSource.from_url(url, loop=bot.loop, stream=True)
            ctx.voice_client.play(player, after=lambda e: print(f'Erreur de lecture: {e}') if e else None)
            
            await ctx.send(f'🎵 Lecture en cours : **{player.title}**')
        except Exception as e:
            await ctx.send(f"❌ Une erreur s'est produite : {str(e)}")

@bot.command(name='pause', help='Met en pause la musique')
async def pause(ctx):
    """Met en pause la musique"""
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.pause()
        await ctx.send("⏸️ Musique mise en pause")
    else:
        await ctx.send("❌ Aucune musique n'est en cours de lecture")

@bot.command(name='resume', help='Reprend la musique')
async def resume(ctx):
    """Reprend la musique"""
    if ctx.voice_client and ctx.voice_client.is_paused():
        ctx.voice_client.resume()
        await ctx.send("▶️ Musique reprise")
    else:
        await ctx.send("❌ Aucune musique n'est en pause")

@bot.command(name='stop', help='Arrête la musique et déconnecte le bot')
async def stop(ctx):
    """Arrête la musique et déconnecte le bot"""
    if ctx.voice_client:
        ctx.voice_client.stop()
        await ctx.voice_client.disconnect()
        await ctx.send("⏹️ Musique arrêtée et déconnexion")
    else:
        await ctx.send("❌ Le bot n'est pas connecté à un salon vocal")

@bot.command(name='skip', help='Passe à la musique suivante')
async def skip(ctx):
    """Passe à la musique suivante"""
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.stop()
        await ctx.send("⏭️ Musique passée")
    else:
        await ctx.send("❌ Aucune musique n'est en cours de lecture")

@bot.command(name='volume', aliases=['vol'], help='Change le volume (0-100)')
async def volume(ctx, volume: int):
    """Change le volume de la musique"""
    if ctx.voice_client is None:
        return await ctx.send("❌ Le bot n'est pas connecté à un salon vocal")

    if 0 <= volume <= 100:
        ctx.voice_client.source.volume = volume / 100
        await ctx.send(f"🔊 Volume réglé à {volume}%")
    else:
        await ctx.send("❌ Le volume doit être entre 0 et 100")

@bot.command(name='leave', aliases=['disconnect', 'dc'], help='Déconnecte le bot du salon vocal')
async def leave(ctx):
    """Déconnecte le bot du salon vocal"""
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send("👋 Déconnexion du salon vocal")
    else:
        await ctx.send("❌ Le bot n'est pas connecté à un salon vocal")

@bot.command(name='ping', help='Affiche la latence du bot')
async def ping(ctx):
    """Affiche la latence du bot"""
    await ctx.send(f'🏓 Pong! Latence: {round(bot.latency * 1000)}ms')

# Gestion des erreurs
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send(f"❌ Commande inconnue. Utilisez `{PREFIX}help` pour voir les commandes disponibles.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Argument manquant. Utilisez `{PREFIX}help {ctx.command}` pour plus d'informations.")
    else:
        await ctx.send(f"❌ Une erreur s'est produite : {str(error)}")
        print(f"Erreur: {error}")

if __name__ == '__main__':
    bot.run(TOKEN)

