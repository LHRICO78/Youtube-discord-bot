# Bot Discord de Musique pour Pterodactyl

Ce projet contient un bot Discord de musique simple qui peut lire des vidéos YouTube. Il est conçu pour être déployé facilement sur un panel Pterodactyl à l'aide de l'egg fourni.

## Fonctionnalités

- Lire de la musique depuis YouTube (via URL ou recherche)
- Commandes de lecture : `play`, `pause`, `resume`, `stop`, `skip`
- Contrôle du volume : `volume`
- Afficher la latence du bot : `ping`
- Déconnexion du salon vocal : `leave`

## Fichiers Inclus

- `bot.py`: Le code source principal du bot Discord.
- `requirements.txt`: La liste des dépendances Python nécessaires.
- `egg-discord-music-bot.json`: Le fichier de configuration de l'egg pour Pterodactyl.
- `.env.example`: Un exemple de fichier de configuration pour les variables d'environnement.

## Déploiement sur Pterodactyl

1.  **Importer l'egg** : Allez dans la section "Nests" de votre panel Pterodactyl et importez le fichier `egg-discord-music-bot.json`.
2.  **Créer un nouveau serveur** : Créez un nouveau serveur en utilisant l'egg que vous venez d'importer.
3.  **Configurer les variables** : Dans l'onglet "Startup" de votre serveur, remplissez la variable `DISCORD_TOKEN` avec le token de votre bot Discord.
4.  **Démarrer le serveur** : Démarrez le serveur. Pterodactyl installera automatiquement les dépendances et lancera le bot.

## Utilisation

- Invitez le bot sur votre serveur Discord.
- Utilisez la commande `!play <URL ou nom de la vidéo>` pour commencer à écouter de la musique.
- Utilisez `!help` pour voir la liste complète des commandes.

